import os

os.chdir("C:\\Users\\Orange-pc\\Desktop.")

NewFile = open('Нармалния.txt', 'w')

NewFile.write("Hi нармалния! \n\nYou are the best")

NewFile.close()

# print(os.getcwd())
