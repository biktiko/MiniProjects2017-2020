import os 

def copy(folder, newFolder, expansion):
    os.chdir(folder)
    


folder = 'D:\\Тигран\\TigranProgrammerHistory\\Python\\Автоматизация рутинных задач'
newFolder = 'D:\\Тигран\\TigranProgrammerHistory\\Python\\Автоматизация рутинных задач\\Projects\\Selective Copying\\newFiles'

copy(folder, newFolder, 'py')