import random
# from random import *


for i in range(5):
    print(random.randint(1, 10))

              